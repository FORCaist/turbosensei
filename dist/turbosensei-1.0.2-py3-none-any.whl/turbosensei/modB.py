def funcB(x):

    return x+2